from setuptools import find_packages, setup

setup(
    name="cex-adaptor",
    version="1.0.0",
    packages=find_packages(),
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
)
